// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import 'sentecesGames/_services.dart';
// import 'Home.dart';
// import 'myDictionary/_Provider.dart';

// void main() {
//   runApp(const MyApp());
// }

// class MyApp extends StatelessWidget {
//   const MyApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return MultiProvider(
//       providers: [
//         ChangeNotifierProvider(
//             create: (context) => ClickedButtonListProvider()),
//         ChangeNotifierProvider(create: (context) => WordProvider())
//       ],
//       child: MaterialApp(
//         debugShowCheckedModeBanner: false,
//         initialRoute: '/home',
//         routes: {
//           '/home': (context) => Home(),
//           // '/ButtonTransfer': (context) => ButtonTransfer(),
//         },
//       ),
//     );
//   }
// }


import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import './beginner/_servicesBeginner.dart'; // Menggunakan nama file yang baru
import 'Home.dart';
import 'myDictionary/_Provider.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => BeginnerButtonListProvider(),
        ),
        ChangeNotifierProvider(
          create: (context) => WordProvider(),
        ),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        initialRoute: '/home',
        routes: {
          '/home': (context) => Home(),
        },
      ),
    );
  }
}
