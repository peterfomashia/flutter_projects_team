// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import './myDictionary/dictionary.dart';
// import './sentecesGames/_services.dart';
// import './sentecesGames/englishStructuredSentences.dart';

// class Home extends StatelessWidget {
//   Home({super.key});
//   final tabs = ['Sedang Dipelajari', 'Telah Dipelajari'];

//   Future<bool?> AllertDial(BuildContext context) {
//     var state = Provider.of<ClickedButtonListProvider>(context, listen: false);
//     return showDialog<bool>(
//         context: context,
//         builder: (BuildContext context) {
//           return AlertDialog(
//             title: Text("Are you sure?"),
//             content: Text("Are you want back to previous game?"),
//             actions: <Widget>[
//               TextButton(
//                   onPressed: () {
//                     state.notify();
//                     Navigator.pop(context);
//                     Navigator.push(
//                       context,
//                       MaterialPageRoute(builder: (context) => ButtonTransfer()),
//                     );
//                   },
//                   child: Text("No")),
//               TextButton(
//                   onPressed: () {
//                     Navigator.pop(context);
//                     Navigator.push(
//                       context,
//                       MaterialPageRoute(builder: (context) => ButtonTransfer()),
//                     );
//                   },
//                   child: Text("Yes, I want to Continue"))
//             ],
//           );
//         });
//   }

//   @override
//   Widget build(BuildContext context) {
//     var useState = Provider.of<ClickedButtonListProvider>(context);
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Provider Prototype'),
//       ),
//       body: Center(
//         child: Container(
//           height: MediaQuery.of(context).size.height * 0.5,
//           width: MediaQuery.of(context).size.width * 0.5,
//           color: Colors.lightBlue.shade300,
//           child: Center(
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               crossAxisAlignment: CrossAxisAlignment.center,
//               children: [
//                 ElevatedButton(
//                   onPressed: () {
//                     if (useState.indexing > 0 ||
//                         useState.firstContainer.isNotEmpty) {
//                       AllertDial(context);
//                     } else {
//                       useState.notify();
//                       Navigator.push(
//                         context,
//                         MaterialPageRoute(
//                             builder: (context) => ButtonTransfer()),
//                       );
//                     }
//                   },
//                   child: Text('Navigate to ButtonTransfer'),
//                 ),
//                 ElevatedButton(
//                   onPressed: () {
//                     Navigator.push(
//                       context,
//                       MaterialPageRoute(
//                           builder: (context) => DefaultTabController(
//                                 length: 2,
//                                 child: WordListScreen(),
//                               )),
//                     );
//                   },
//                   child: Text('Navigate to WordListScreen'),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import './myDictionary/dictionary.dart';
import './beginner/_servicesBeginner.dart';
import './beginner/Sentences.dart'; 

class Home extends StatelessWidget {
  Home({super.key});
  final tabs = ['Sedang Dipelajari', 'Telah Dipelajari'];

  Future<bool?> AllertDial(BuildContext context) {
    var state = Provider.of<BeginnerButtonListProvider>(context, listen: false);
    return showDialog<bool>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Are you sure?"),
            content: Text("Are you want back to previous game?"),
            actions: <Widget>[
              TextButton(
                  onPressed: () {
                    state.notify();
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => ButtonTransferBeginner()),
                    );
                  },
                  child: Text("No")),
              TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => ButtonTransferBeginner()),
                    );
                  },
                  child: Text("Yes, I want to Continue"))
            ],
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    var useState = Provider.of<BeginnerButtonListProvider>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('Provider Prototype'),
      ),
      body: Center(
        child: Container(
          height: MediaQuery.of(context).size.height * 0.5,
          width: MediaQuery.of(context).size.width * 0.5,
          color: Colors.lightBlue.shade300,
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    if (useState.indexing > 0 ||
                        useState.firstContainer.isNotEmpty) {
                      AllertDial(context);
                    } else {
                      useState.notify();
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ButtonTransferBeginner()),
                      );
                    }
                  },
                  child: Text('Navigate to ButtonTransfer'),
                ),


                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => DefaultTabController(
                                length: 2,
                                child: WordListScreen(),
                              )),
                    );
                  },
                  child: Text('Navigate to WordListScreen'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
