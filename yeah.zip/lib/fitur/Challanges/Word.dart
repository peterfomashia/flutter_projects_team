class WordPairs {
  static Map<String, String> data = {
    "cat": "kucing",
    "dog": "anjing",
    "tree": "pohon",
    "sun": "matahari",
    "book": "buku",
    "water": "air",
    "glass": "gelas",
    "bucket": "ember",
    "plate": "piring",
    "spoon": "sendok",
    "tomorrow": "besok",
    "yesterday": "kemarin",
    "sunday": "minggu",
    "tuesday": "selasa",
    "today": "hari ini",
    "table": "meja",
    "chair": "kursi",
    "cheat": "mencurangi",
    "light up": "menyala",
    "put out": "memadamkan",
    // Tambahkan pasangan kata baru di sini jika diperlukan
  };
}
